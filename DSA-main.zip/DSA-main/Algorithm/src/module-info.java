/**
 * 
 */
/**
 * 
 */
module KruskalsMST {
}