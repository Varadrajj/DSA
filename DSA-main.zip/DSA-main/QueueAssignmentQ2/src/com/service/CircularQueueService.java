package com.service;

public interface CircularQueueService {

}
