package com.dao;

public interface CircularQueue {

}
