package com.test;

import com.beans.MyLinkedListQueue;

public class TestQueueLL {

	public static void main(String[] args) {
	MyLinkedListQueue ob=new MyLinkedListQueue();
    ob.enqueue(10);
	}

}
