/**
 * 
 */
/**
 * 
 */
module GraphTrav {
}