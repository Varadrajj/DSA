/**
 * 
 */
/**
 * 
 */
module GraphBasic {
}